<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Transaction_summary extends Model
{
    use HasFactory;

    // protected $fillable = ['name', 'email', 'phone_number', 'address'];

}
